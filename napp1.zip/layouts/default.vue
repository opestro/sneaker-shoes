<template>

<div>
  
 <Nuxt />
 </div>
</template>

<script>

</script>
