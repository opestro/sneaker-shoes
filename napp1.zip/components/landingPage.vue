<template>
    <div>

<body>
    
            <main class="l-main">
        <!--===== HOME =====-->
        <section class="home" id="home">

            <div class="home__container bd-grid">
                <div class="home__sneaker">
                    <div class="home__shape"></div>
                    <img src="~/assets/img/imghome.png" alt="Sneaker" class="home__img">
                </div>

                <div class="home__data">
                    <!-- <span class="home__new">New in</span> -->
                    <p class="home__title">Telbes Wahdek</p>
                    <h1 class="home__description">Ghir 9elb L'hebba ou Lmarka La Tchitchi</h1>
                    <a href="#featured" class="button">Edkhol Tka7el  !</a>
                </div>
            </div>

        </section>


        <!--===== FEATURED =====-->
        <section class="featured section" id="featured">
            <h2 class="section-title">Featured</h2>
            <div class="featured__container bd-grid">

                <article class="sneaker">
                    <img src="~/assets/img/new.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Armani Exchange</span>
                    <span class="sneaker__price">26000 DA</span>
                    <a href="#featured" class="button-light">View Product <i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">   

                    <img src="~/assets/img/featured2.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Premiata Lander</span>
                    <span class="sneaker__price">44000 DA</span>
                    <a href="#featured" class="button-light">View Product <i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">

                    <img src="~/assets/img/featured4.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Harmont & Blaine </span>
                    <span class="sneaker__price">24000 DA</span>
                    <a href="#featured" class="button-light">View Product <i data-feather="arrow-right"></i></a>
                </article>
            </div>
        </section>


        <!--===== COLLECTION =====-->
        <section class="collection section" id="collection">
            <h2 class="section-title">Collections</h2>
            <div class="collection__container bd-grid">
                <div class="collection__card">
                    <div class="collection__data">
                        <p></p>
                        <h3 class="collection__name">EA7 Milano</h3>
                        <p class="collection__description">New collection 2022</p>
                        <p></p>
                        <a href="" class="button-light">View Collection<i data-feather="arrow-right"></i></a>
                    </div>
                    <img src="~/assets/img/collection3-1.png" alt="" class="collection__img">
                </div>

                <div class="collection__card">
                    <div class="collection__data">
                        <h3 class="collection__name">Hugo Boss</h3>
                        <p class="collection__description">New collection 2022</p>
                        <a href="#" class="button-light">View Collection<i data-feather="arrow-right"></i></a>
                    </div>
                    <img src="~/assets/img/collection2.png" alt="" class="collection__img">
                </div>
                
            </div>

        </section>


        <!--===== MEN SNEAKERS =====-->
        <section class="women section" id="women">
            <h2 class="section-title">Men Sneakers</h2>
            <div class="women__container bd-grid">

                <article class="sneaker">

                    <img src="~/assets/img/men1.png" alt="Sneaker" class="sneaker__img">
                    <span class="sneaker__name">Emporio Armani</span>
                    <span class="sneaker__price">28000 DA</span>
                    <a href="product.html" class="button-light">View Product <i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">

                    <img src="~/assets/img/men2.png" alt="Sneaker" class="sneaker__img">
                    <span class="sneaker__name">Emporio Armani</span>
                    <span class="sneaker__price">34000 DA</span>
                    <a href="product.html" class="button-light">View Product <i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">

                    <img src="~/assets/img/men6.png" alt="Sneaker" class="sneaker__img">
                    <span class="sneaker__name">Armani Exchange </span>
                    <span class="sneaker__price">25000 DA</span>
                    <a href="product.html" class="button-light">View Product <i data-feather="arrow-right"></i></a>
                </article>
                <article class="sneaker">

                    <img src="~/assets/img/men4.png" alt="Sneaker" class="sneaker__img">
                    <span class="sneaker__name">Premiata Lander</span>
                    <span class="sneaker__price">44000 DA</span>
                    <a href="product.html" class="button-light">View Product <i data-feather="arrow-right"></i></a>
                </article>
                
            </div>
        </section>

        <!--===== WOMEN SNEAKERS =====-->
        <section class="women section" id="women">
            <h2 class="section-title">Women Sneakers</h2>
            <div class="women__container bd-grid">

                <article class="sneaker">

                    <img src="~/assets/img/women1.png" alt="Sneaker" class="sneaker__img">
                    <span class="sneaker__name">Emporio Armani</span>
                    <span class="sneaker__price">34000 DA</span>
                    <a href="product.html" class="button-light">View Product <i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">

                    <img src="~/assets/img/women2.png" alt="Sneaker" class="sneaker__img">
                    <span class="sneaker__name">Emporio Armani</span>
                    <span class="sneaker__price">36000 DA</span>
                    <a href="product.html" class="button-light">View Product <i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">

                    <img src="~/assets/img/women3.png" alt="Sneaker" class="sneaker__img">
                    <span class="sneaker__name">Emporio Armani</span>
                    <span class="sneaker__price">24000 DA</span>
                    <a href="product.html" class="button-light">View Product <i data-feather="arrow-right"></i></a>
                </article>

            </div>
        </section>


       

       
        <!--===== NEWSLETTER =====-->


        <section class="newsletter section">
            <div class="newsletter__container bd-grid">
                <div class="newsletter__card">
                    <div>
                        <h3 class="newsletter__title">Subscribe to our newsletter <br> and
                            receive exclusive offers <br> every week</h3>
                        <!-- <p class="newsletter__description">Get 10% dicount in Adidas Products</p> -->
                    </div>
                    <form action="" class="newsletter__subs">
                        <input type="mail" placeholder="Enter your email" class="newsletter__input">
                        <a href="#" class="button">Subscribe</a>
                    </form>
                </div>

            </div>
        </section>

    </main></body>

    </div>
</template>
<script>
export default {
beforeMount(){
      feather.replace()
}

}
</script>