<template>
<div>

   <div class="footer section">
        <div class="footer__container bd-grid">
            <div class="footer__box">
                <h3 class="footer__title"> <b>Sneaker</b> Shoes </h3>
                <p class="footer__description">New collection of shoes 2022.</p>
            </div>

           

            <div class="footer__box">
                <h3 class="footer__title"> Support</h3>
                <ul class="">
                    <li class=""><a href="#" class="footer__link">Product Help</a></li>
                    <li class=""><a href="#" class="footer__link">Customer Help</a></li>
                    <li class=""><a href="#" class="footer__link">Athorized service</a></li>
                </ul>
            </div>

            <div class="footer__box">
                <a href="" class="footer__social"><i class="fab fa-facebook"></i></a>
                <a href="" class="footer__social"><i class="fab fa-instagram"></i></a>
                <a href="" class="footer__social"><i class="fab fa-twitter"></i></a>
                <a href="" class="footer__social"><i class="fab fa-youtube"></i></a>
            </div>
        </div>

        <p class="footer__copy">&#169; SneakerShoes 2022. All rights reserved  - Template by Youness & Trensfermed to Nuxt-js by Mehdi Harzallah.</p>
    
    </div>
</div>
</template>