<template>
    <div>
        <body>
                <main class="l-main">
        <!-- All products -->
        <section class="featured section" id="Shop">
            <h2 class="section-title">All products</h2>
            <div class="featured__container bd-grid">

                <article class="sneaker">
                    <img src="~/assets/img/new.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Armani Exchange</span>
                    <span class="sneaker__price">25000 DA</span>
                    <a href="product.html" class="button-light">View Product<i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">
                    <img src="~/assets/img/featured2.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Premiata Lander</span>
                    <span class="sneaker__price">44000 DA</span>
                    <a href="product.html" class="button-light">View Product<i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">
                    <img src="~/assets/img/featured1.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Armani Exchange</span>
                    <span class="sneaker__price">25000 DA</span>
                    <a href="product.html" class="button-light">View Product<i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">
                    <img src="~/assets/img/featured3.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Emporio Armani Milano</span>
                    <span class="sneaker__price">26000 DA</span>
                    <a href="product.html" class="button-light">View Product<i data-feather="arrow-right"></i></a>
                </article>



                <article class="sneaker">
                    <img src="~/assets/img/featured4.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Harmont & Blaine</span>
                    <span class="sneaker__price">34000 DA</span>
                    <a href="product.html" class="button-light">View Product<i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">
                    <img src="~/assets/img/new2.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Emporio Armani Signature</span>
                    <span class="sneaker__price">33000 DA</span>
                    <a href="product.html" class="button-light">View Product<i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">
                    <img src="~/assets/img/new3.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Premiata Lander</span>
                    <span class="sneaker__price">44000 DA</span>
                    <a href="product.html" class="button-light">View Product<i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">
                    <img src="~/assets/img/new4.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Emporio Armani Milano</span>
                    <span class="sneaker__price">26000 DA</span>
                    <a href="product.html" class="button-light">View Product<i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">
                    <img src="~/assets/img/new5.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Armani Exchange</span>
                    <span class="sneaker__price">29000 DA</span>
                    <a href="product.html" class="button-light">View Product<i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">
                    <img src="~/assets/img/women1.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Emporio Armani Women</span>
                    <span class="sneaker__price">31000 DA</span>
                    <a href="product.html" class="button-light">View Product<i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">
                    <img src="~/assets/img/women2.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Emporio Armani Women</span>
                    <span class="sneaker__price">34000 DA</span>
                    <a href="product.html" class="button-light">View Product<i data-feather="arrow-right"></i></a>
                </article>

                <article class="sneaker">
                    <img src="~/assets/img/women3.png" alt="Sneaker" class="">
                    <span class="sneaker__name">Emporio Armani Women</span>
                    <span class="sneaker__price">28000 DA</span>
                    <a href="product.html" class="button-light">View Product<i data-feather="arrow-right"></i></a>
                </article>
            </div>

            <div class="sneaker__pages bd-grid">
                <div>
                    <span class="sneaker__pag">1</span>
                   
                    <span class="sneaker__pag">&#8594;</span>
                </div>
            </div>
        </section>
    </main> 
                
            </body>
    </div>
</template>
<script>
export default {
    beforeMount(){
      feather.replace()
}
}
</script>